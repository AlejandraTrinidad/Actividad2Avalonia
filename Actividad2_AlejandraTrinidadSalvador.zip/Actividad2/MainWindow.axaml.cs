using Avalonia.Controls;

namespace ProyectoDos;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void OnClick(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
    }
}